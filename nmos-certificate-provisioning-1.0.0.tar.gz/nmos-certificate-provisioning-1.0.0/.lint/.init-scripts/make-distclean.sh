#!/bin/bash

set -o errexit

rm -rf package.json node_modules/ yarn.lock package-lock.json .scripts/
